#!/bin/bash
# 自动重试编译循环：被杀/报错就自动重来，直到成功
cd /home/user/Doubao/chats/271985545762818/starling || exit 1
export PATH=$HOME/.cargo/bin:$PATH
export ANDROID_NDK_HOME=/home/user/android-ndk-r28c
export CARGO_INCREMENTAL=0
export MALLOC_ARENA_MAX=2
SHIM=/home/user/Doubao/chats/271985545762818/nolock.so
if [ ! -f "$SHIM" ]; then
  printf 'int flock(int fd,int op){return 0;}\n' > /tmp/nolock.c
  gcc -shared -fPIC -O1 -o "$SHIM" /tmp/nolock.c
fi
export LD_PRELOAD=$SHIM
LOG=/home/user/Doubao/chats/271985545762818/buildloop.log
for i in $(seq 1 30); do
  echo "===== 第 $i 次尝试 $(date +%H:%M:%S) =====" >> $LOG
  cargo ndk -t arm64-v8a --platform 26 build --profile quick -p horizon-android --jobs 1 >> $LOG 2>&1
  rc=$?
  if [ $rc -eq 0 ]; then
    echo "===== 编译成功 $(date +%H:%M:%S) =====" >> $LOG
    export ANDROID_HOME=/home/user/android-sdk
    export JAVA_HOME=/home/user/jdk-17.0.13+11
    python3 packaging/android/build_apk.py --no-build --profile quick >> $LOG 2>&1
    echo "===== 打包结束 rc=$? $(date +%H:%M:%S) =====" >> $LOG
    break
  fi
  echo "第 $i 次失败 rc=$rc，10 秒后重试" >> $LOG
  sleep 10
done
